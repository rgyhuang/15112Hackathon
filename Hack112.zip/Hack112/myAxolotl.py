from axolotlClass import*
axolotl = Axolotl("")
